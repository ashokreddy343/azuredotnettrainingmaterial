﻿#Connect to azure resouce manager account, login using credentials
Add-AzureRmAccount

#List the available subscriptions
Get-AzureRmSubscription 

#select and active subscription by its id
Select-AzureRmSubscription -SubscriptionId "93481ab3-d4e9-4640-933d-9d67acf4371d" 

#Create a new Azure resouce group (Optional), You can use an existing resouce group also
New-AzureRmResourceGroup -Name "azureapps2016" -Location "SouthEast Asia"

#create new azure sql server
New-AzureRmSqlServer -ResourceGroupName "azureapps2016" -ServerName "psserver1" -Location "Southeast Asia" -ServerVersion "12.0" 

#If you want to list the location names
Get-AzureLocation 

#set the firewall rule for the client to access the server
New-AzureRmSqlServerFirewallRule -ResourceGroupName "azureapps2016" -ServerName "psserver1" -FirewallRuleName "MyRule1" -StartIpAddress "182.0.0.1" -EndIpAddress "182.100.0.255"

#create new sql database inside the server
New-AzureRmSqlDatabase -DatabaseName "MydemoDB" -Edition Standard -ServerName "psserver1" -ResourceGroupName "azureapps2016"

#remove and existing database
Remove-AzureRmSqlDatabase -DatabaseName "MydemoDB" -ServerName "psserver1" -ResourceGroupName "azureapps2016" -Force

#remove sql server
Remove-AzureRmSqlServer -ServerName "psserver1" -ResourceGroupName "azureapps2016" -Force

#remove resouce group
Remove-AzureRmResourceGroup -Name "azureapps2016" -Force 