
 ### Create VM and Load Balance it
  ## Load Balancing Provides a higher level of availability by spreading incoming requests
  # across multiple vm. 

   # Azure Load Balancer is a Layer-4 TCP/UDP load balancer that provides high availability
   # by destributing  incoming traffic to healthy VM.
   # Azure load balancer has health probe that monitors a giver port on each VM and 
   # only distributes traffic to  an operational VM
   # You need to define  front-end IP Configuration that contains one or more Public IP addresses
   # This fron end IP configuration allows your load balancer and applications to be accessible
   # over the internet. 
   # Virtual machines connect to load balancer using NIC  To distribute traffic to the VMS
   # a back end address pool contains the IP addresses of Virtual NICs connected to the load balancer
   # To control the flow of traffic , you define the load balancer rules for specific ports and protocols

    ## Step 1 : Create Load Balancer
    New-AzureRmResourceGroup `
  -ResourceGroupName "swpnlgkwdLoadBalancer" `
  -Location "EastUS"

   ## Step 2: To access your app on the internet you need public IP address for LB. 
   $publicIP = New-AzureRmPublicIpAddress `
  -ResourceGroupName "swpnlgkwdLoadBalancer" `
  -Location "EastUS" `
  -AllocationMethod "Static" `
  -Name "swpnlgkwdPublicIP"

  ## Step 3 : Create a Load Balancer
   # create fronEndIP pool  and attaches the publicIP address

   $frontendIP = New-AzureRmLoadBalancerFrontendIpConfig `
  -Name "myFrontEndPool" `
  -PublicIpAddress $publicIP
   
   # Create backend address pool the vMs attach to thi backend pool . VMS will be attached to this backend pool
   $backendPool = New-AzureRmLoadBalancerBackendAddressPoolConfig -Name "myBackEndPool"

   # Create a Load Balancer with frontEndpool and backEndPool
   $lb = New-AzureRmLoadBalancer `
  -ResourceGroupName "swpnlgkwdLoadBalancer" `
  -Name "swpnlgkwdLoadBalancer" `
  -Location "EastUS" `
  -FrontendIpConfiguration $frontendIP `
  -BackendAddressPool $backendPool

  # Create a Health Probe
  # To allow monitor the status of your app  you use health probe. 
  # The health probe dynamically adds or removes VMS from the load balancer rotation based on their response to health checks
  # by default VM is removed from the load balancer after 2 consecutive failures at 15 sec intervals

  # Creates a Health Probe that monitors port 80
  Add-AzureRmLoadBalancerProbeConfig `
  -Name "myHealthProbe" `
  -LoadBalancer $lb `
  -Protocol tcp `
  -Port 80 `
  -IntervalInSeconds 15 `
  -ProbeCount 2

 # To update the health probes update the load balancer
 Set-AzureRmLoadBalancer -LoadBalancer $lb

 ### Create a Load Balancer Rule
 # ITs use to define how traffic is distributed to the VMS
 # you define the  fronEndIP configurations for the incmoing traffic and the backend IP pool
 # to receive traffic and back end IP pool to receive the traffic along with required source and desination port
 $probe = Get-AzureRmLoadBalancerProbeConfig -LoadBalancer $lb -Name "myHealthProbe"

Add-AzureRmLoadBalancerRuleConfig `
  -Name "swpnlgkwdLoadBalancer" `
  -LoadBalancer $lb `
  -FrontendIpConfiguration $lb.FrontendIpConfigurations[0] `
  -BackendAddressPool $lb.BackendAddressPools[0] `
  -Protocol Tcp `
  -FrontendPort 80 `
  -BackendPort 80 `
  -Probe $probe

# Uploda the Balancer
Set-AzureRmLoadBalancer -LoadBalancer $lb
 
# Create a network Resources

# Create subnet config
$subnetConfig = New-AzureRmVirtualNetworkSubnetConfig `
  -Name "mySubnet" `
  -AddressPrefix 192.168.1.0/24

# Create the virtual network
$vnet = New-AzureRmVirtualNetwork `
  -ResourceGroupName "swpnlgkwdLoadBalancer" `
  -Location "EastUS" `
  -Name "myVnet" `
  -AddressPrefix 192.168.0.0/16 `
  -Subnet $subnetConfig

  # Virtual NICs are created with  New-AzureRmNetworkInterface. Following strps Creates 3 Virtual NIC
  # each NIC created for each VM.

  for ($i=1; $i -le 3; $i++)
{
   New-AzureRmNetworkInterface `
     -ResourceGroupName "swpnlgkwdLoadBalancer" `
     -Name myVM$i `
     -Location "EastUS" `
     -Subnet $vnet.Subnets[0] `
     -LoadBalancerBackendAddressPool $lb.BackendAddressPools[0]
}
 ## Create a Virtual Machine with high availability 

 $availabilitySet = New-AzureRmAvailabilitySet `
  -ResourceGroupName "swpnlgkwdLoadBalancer" `
  -Name "myAvailabilitySet" `
  -Location "EastUS" `
  -Sku aligned `
  -PlatformFaultDomainCount 2 `
  -PlatformUpdateDomainCount 2

  $cred = Get-Credential

  for ($i=1; $i -le 3; $i++)
{
    New-AzureRmVm `
        -ResourceGroupName "swpnlgkwdLoadBalancer" `
        -Name "myVM$i" `
        -Location "East US" `
        -VirtualNetworkName "myVnet" `
        -SubnetName "mySubnet" `
        -SecurityGroupName "myNetworkSecurityGroup" `
        -OpenPorts 80 `
        -AvailabilitySetName "myAvailabilitySet" `
        -Credential $cred `
        -AsJob
}
 ### Install Custom IIS using Script Extension

 for ($i=1; $i -le 3; $i++)
{
   Set-AzureRmVMExtension `
     -ResourceGroupName "swpnlgkwdLoadBalancer" `
     -ExtensionName "IIS" `
     -VMName myVM$i `
     -Publisher Microsoft.Compute `
     -ExtensionType CustomScriptExtension `
     -TypeHandlerVersion 1.8 `
     -SettingString '{"commandToExecute":"powershell Add-WindowsFeature Web-Server; powershell Add-Content -Path \"C:\\inetpub\\wwwroot\\Default.htm\" -Value $($env:computername)"}' `
     -Location EastUS
}


 ### Get the IP address of the Load Balancer

 Get-AzureRmPublicIPAddress `
  -ResourceGroupName "myResourceGroupLoadBalancer" `
  -Name "myPublicIP" | select IpAddress 