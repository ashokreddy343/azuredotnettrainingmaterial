﻿Function New-AzVirtualNetwork(){
         [CmdletBinding()]
        Param(
            [Parameter(Mandatory=$true,HelpMessage="Name of the Resource Group")]           
            [string]$ResourceGroupName,
            [Parameter(Mandatory=$true,HelpMessage="Name of the Location")]          
            [string]$Location,            
            [Parameter(Mandatory=$true,HelpMessage="Name of FrontEndSubnetName")]
            [string]$FrontEndSubNetName,            
            [Parameter(Mandatory=$true,HelpMessage="Address of Front End Subnet")]
            [string]$FrontEndSubNetAddress,            
            [Parameter(Mandatory=$true,HelpMessage="Name of BackEndSubnetName")]
            [string]$BackEndSubNetName,            
            [Parameter(Mandatory=$true,HelpMessage="Address of Back end Sibnet")]
            [string]$BackEndAddressSpace,            
            [Parameter(Mandatory=$true,HelpMessage="VirtualNetwork Name")]
            [string]$VirtualNetName,            
            [Parameter(Mandatory=$true,HelpMessage="Virtual Network Address")]
            [string]$VirtualNetAddressSpace
            ) 

    
     # Check if the Virtual Network Exists or not
     <# $virtualNetwork=  Get-AzureRmVirtualNetwork `
                       -Name $VirtualNetName `
                       -ResourceGroupName $ResourceGroupName `
                       -ErrorAction SilentlyContinue
        #>

        $virtualNetwork = Check-AzVirtualNetwork -ResourceGroupName $ResourceGroupName `
                        -Name $VirtualNetName

    # Create Virtual Network

        if($virtualNetwork -eq $null){  
                # Create FrontEnd Subnet  
                   
            $frontendSubnet = New-AzureRmVirtualNetworkSubnetConfig `
                             -Name $FrontEndSubNetName `
                             -AddressPrefix $FrontEndSubNetAddress  

                # Create BackEnd Subnet    
            $backendSubnet  = New-AzureRmVirtualNetworkSubnetConfig `
                              -Name $BackEndSubNetName `
                              -AddressPrefix $BackEndAddressSpace
         
           $virtualNetwork= New-AzureRmVirtualNetwork `
             -Name $VirtualNetName `
             -ResourceGroupName $ResourceGroupName `
             -Location $Location `
             -AddressPrefix $VirtualNetAddressSpace `
             -Subnet $frontendSubnet,$backendSubnet

             Write-Host "Virtual Network Created Successfully"
        }
        else{
         Write-Verbose "Virtual Network Already Exists"
         Write-Host "Virtual Network Already Exists"
        }
       
        return $virtualNetwork
}

Function Check-AzVirtualNetwork(){
        
            Param(
             
             [Parameter(Mandatory=$true,HelpMessage="Name of the Resource Group")]           
            [string]$ResourceGroupName,
            [Parameter(Mandatory=$true,HelpMessage="Name of the Location")]          
            [string]$Name  
            
            )       
           

           $virtualNetwork=  Get-AzureRmVirtualNetwork `
                       -Name $VirtualNetName `
                       -ResourceGroupName $ResourceGroupName `
                       -ErrorAction SilentlyContinue

            return $virtualNetwork
}
