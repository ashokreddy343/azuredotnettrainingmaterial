﻿#FirstVNET creation 
$resourceGroupName="HybridCloudResourceGroup1"

$firstVNETName="FirstVNET"
$firstVNETLocation="Southeast Asia"
$firstVNETAddressSpace="10.11.0.0/16"
$frontEndSubnetName ="FrontEnd"
$backEndSubnetName = "BackEnd"
$fnGatewaySubnetName="GatewaySubnet"
$frontEndSubnetIPrange ="10.11.1.0/24"
$backEndSubnetIPrange ="10.11.2.0/24"
$fnGatewaySubnetIPrange ="10.11.3.0/27"

#Create Subnet configurations for FirstVNET
$frontEndSubnet=New-AzureRmVirtualNetworkSubnetConfig -Name $frontEndSubnetName -AddressPrefix $frontEndSubnetIPrange
$backEndSubnet=New-AzureRmVirtualNetworkSubnetConfig -Name $backEndSubnetName -AddressPrefix $backEndSubnetIPrange
$firstVNETGatewaySubnet=New-AzureRmVirtualNetworkSubnetConfig -Name $fnGatewaySubnetName -AddressPrefix $fnGatewaySubnetIPrange

#Create FirstVNET
New-AzureRmVirtualNetwork -Name $firstVNETName `
                -ResourceGroupName $resourceGroupName `
                -Location $firstVNETLocation `
                -AddressPrefix $firstVNETAddressSpace `
                -Subnet $frontEndSubnet,$backEndSubnet,$firstVNETGatewaySubnet