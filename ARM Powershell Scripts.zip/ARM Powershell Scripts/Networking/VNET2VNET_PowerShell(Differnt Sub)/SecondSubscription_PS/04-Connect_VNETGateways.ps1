﻿
#Create connection between two gateways

$resourceGroupName="HybridCloudResourceGroup2"
$GatewayName="SecondVNETGateway"
$VNETLocation="East US"
$ConnectionName="SecondVNETtoFirstVNET"
#Get the gateways references
$VNETGateway = Get-AzureRmVirtualNetworkGateway -Name $GatewayName -ResourceGroupName $resourceGroupName

#Send the following values to the first subscription administrator to establish connection
$VNETGateway.Name
$VNETGateway.Id

#Connecting SecondVNET to FirstVNET
#Get the Gateway name and ID from second subscription administrator and store into the following variables
$RemoteGateway = New-Object Microsoft.Azure.Commands.Network.Models.PSVirtualNetworkGateway
$RemoteGateway.Name="FirstVNETGateway"
$RemoteGateway.Id="/subscriptions/c3ce4f8b-0f90-4b9e-ac9b-1319e5f93223/resourceGroups/HybridCloudResourceGroup1/providers/Microsoft.Network/virtualNetworkGateways/FirstVNETGateway";

New-AzureRmVirtualNetworkGatewayConnection -Name $ConnectionName `
                            -ResourceGroupName $resourceGroupName `
                            -VirtualNetworkGateway1 $VNETGateway `
                            -VirtualNetworkGateway2 $RemoteGateway `
                            -Location $VNETLocation `
                            -ConnectionType Vnet2Vnet `
                            -SharedKey 'sample1234'

