﻿#Connect to Azure Account
Login-AzureRmAccount

#Variables
$ResourceGroupName="SQLDataGroup"
$Location="Southeastasia"
$ServerName="syndataserver123"
#$adminlogin="sonusathyadas"
#$password="Password@123"
$firewallRuleName='SQLServerRule'
$startIPAddress='0.0.0.0'
$endIPAddress='255.255.255.255'
$database='ShopDB'

#Create resource group
New-AzureRmResourceGroup -Name $ResourceGroupName -Location $Location

#Creadentials for SQL Server Login
#$credentials= New-Object -TypeName System.Management.Automation.PSCredential `
#        -ArgumentList $adminlogin, $(ConvertTo-SecureString -String $password -AsPlainText -Force)

$credentials=Get-Credential -Message "Enter username and password for SQL Server"

#Create SQL Server
New-AzureRmSqlServer -ServerName $ServerName `
        -Location $Location `
        -ResourceGroupName $ResourceGroupName `
        -SqlAdministratorCredentials $credentials

#Create Firewall rule for SQL Server
New-AzureRmSqlServerFirewallRule -ResourceGroupName $ResourceGroupName `
        -FirewallRuleName $firewallRuleName `
        -StartIpAddress $startIPAddress `
        -EndIpAddress $endIPAddress `
        -ServerName $ServerName 

#Create SQL Database
New-AzureRmSqlDatabase -DatabaseName $database `
        -ResourceGroupName $ResourceGroupName `
        -Edition Standard `
        -ServerName $ServerName `
        -RequestedServiceObjectiveName 'S3'   # It could be Standard S0, S1, S2 etc      