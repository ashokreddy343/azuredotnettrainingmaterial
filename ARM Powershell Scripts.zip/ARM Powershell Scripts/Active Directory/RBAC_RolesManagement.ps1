﻿Login-AzureRmAccount

Set-AzureRmContext -SubscriptionName 'Developer Program Benefit'

#List all available roles - FL -Format List
Get-AzureRmRoleDefinition | FT Name, Description

#List all actions specific to a role
Get-AzureRmRoleDefinition Contributor | FT Actions, NotActions

(Get-AzureRmRoleDefinition "Virtual Machine Contributor").Actions

#Display who has access to a resource or resource group
Get-AzureRmRoleAssignment -ResourceGroupName DeliveryGroup | FL DisplayName, SignInName, RoleDefinitionName


#List the Users and roles assigned for a resource
#Note: To get the resource type
Get-AzureRmResource -ResourceName 'syn-cloudsvc' -ResourceGroupName DeliveryGroup
Get-AzureRmRoleAssignment  -ResourceName 'syn-cloudsvc' -ResourceGroupName DeliveryGroup -ResourceType 'Microsoft.ClassicCompute/domainNames' | FL DisplayName, RoleDefinitionName


#List roles assigned to a user
#ExpandPrincipalGroups -  returns roles directly assigned to the user and to the groups of which the user is a member 
Get-AzureRmRoleAssignment -SignInName 'jamesbell_gmail.com@sonusathyadashotmail.onmicrosoft.com' -ExpandPrincipalGroups |  FL DisplayName, RoleDefinitionName, Scope


#List all users including classic portal admins  and coadministrators
Get-AzureRmRoleAssignment -IncludeClassicAdministrators | FT DisplayName, RoleDefinitionName, ObjectType, Scope

#Assign a role to a user at the resource group scope
New-AzureRmRoleAssignment -SignInName 'jamesbell_gmail.com@sonusathyadashotmail.onmicrosoft.com'`
         -RoleDefinitionName 'Virtual Machine Contributor'`
         -ResourceGroupName DeliveryGroup


#To grant access to a group at the resource scope
Get-AzureRmADGroup -SearchString 'Engineers' # to get object id
New-AzureRmRoleAssignment -ObjectId '9e05ed18-416a-4ee9-808e-506ecd076d7e'`
                    -RoleDefinitionName 'Contributor'`
                    -ResourceName 'syn-cloudsvc'`
                    -ResourceType 'Microsoft.ClassicCompute/domainNames'`
                    -ResourceGroupName DeliveryGroup

#Remove access
Get-AzureRmADGroup -SearchString 'Engineers' # to get object id
Get-AzureRmRoleAssignment | FT DisplayName, RoleDefinitionName, Scope #to get the scope and RoleDefinitionName
Remove-AzureRmRoleAssignment -ObjectId '9e05ed18-416a-4ee9-808e-506ecd076d7e'`
                    -RoleDefinitionName 'Contributor'`
                    -Scope '/subscriptions/c3ce4f8b-0f90-4b9e-ac9b-1319e5f93223/resourceGroups/DeliveryGroup/providers/Microsoft.ClassicCompute/domainNames/syn-cloudsvc'
