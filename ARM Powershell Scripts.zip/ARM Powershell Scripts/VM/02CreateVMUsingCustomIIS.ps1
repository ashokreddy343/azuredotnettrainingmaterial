###  Login

 Login-AzureRmAccount
 Get-AzureRmSubscription
 Set-AzureRmContext -SubscriptionId "37d3d0a6-99f9-492b-87a5-5b88e80bd69c"
### Create a Resource Group
$resourceGpName="swpnlgkwdrg"
$location ="EastUs"
New-AzureRmResourceGroup -ResourceGroupName $resourceGpName -Location $location

# Create Virtual Machine 
# The default latest version is Windows Server 2016 Datacenter
$cred=Get-Credential
$vmName="webservervm"
$vnetName="swpnlgkwdvnet"
$frontEndSubnet="frontEndsubnet"
$nsgGroup="swpngkwdNsgGroup"
$publicIP="swpnlgkwdPublicIP"
New-AzureRmVm `
    -ResourceGroupName $resourceGpName `
    -Name $vmName `
    -Location $location `
    -VirtualNetworkName $vnetName `
    -SubnetName $frontEndSubnet `
    -SecurityGroupName $nsgGroup `
    -PublicIpAddressName $publicIP `
    -Credential $cred


#==================================================================================================
## Connect to VM : Create Remote desktop connection

$publicIpAddress= Get-AzureRmPublicIpAddress -ResourceGroupName $resourceGpName | Select IpAddress

mstsc /v:$publicIpAddress

# Return List of  Image Publisher
Get-AzureRmVMImagePublisher -Location "EastUS"

# Return the list of Image offer

Get-AzureRmVMImageOffer -Location "EastUS" -PublisherName "MicrosoftWindowsServer"

# Return the List of Images

Get-AzureRmVMImageSku -Location "EastUS" -PublisherName "MicrosoftWindowsServer" -Offer "WindowsServer" 
# =================================================================================================
##### Resize the VM

 # List the Size of VM
 Get-AzureRmVMSize -Location "EastUS"
 # if the Desired Size is available then VM is rebooted
 #If the desired size is available, the VM can be resized from a powered-on state, however it is rebooted during the operation.

 $vm = Get-AzureRmVM -ResourceGroupName $resourceGpName  -VMName $vmName

  $vm.HardwareProfile.VmSize = "Standard_DS2_v2"
  Update-AzureRmVM -VM $vm -ResourceGroupName $resourceGpName

  # Sometimes the desired size is not on the clister so VM needs to be deallocated before
  # resize operation.Now that when the VM is powered back any data on the temp disk are removed
  # and the Public IP address change unless a static IP address is being used.

  Stop-AzureRmVM -ResourceGroupName $resourceGpName -Name $vmName -Force
$vm = Get-AzureRmVM -ResourceGroupName $resourceGpName  -VMName $vmName
$vm.HardwareProfile.VmSize = "Standard_F4s"
Update-AzureRmVM -VM $vm -ResourceGroupName $resourceGpName
Start-AzureRmVM -ResourceGroupName $resourceGpName -Name $vm.name

 # Power State
 # Starting ,Running ,Stopping, Stopped : Stopped still incures compute charges
 # Deallocating , deallocated : VM is completely removed from Hypervisor. it doesnt incure  compute charges
 # Find Power Status
 Get-AzureRmVM `
    -ResourceGroupName $resourceGpName `
    -Name  $vmName `
    -Status 

    Get-AzureRmVM `
    -ResourceGroupName $resourceGpName `
    -Name  $vmName `
    -Status | Select @{n="Status"; e={$_.Statuses[1].Code}}
#=====================================================================

#### Manage Azure Disks : OsDisk and Temp Disk
# Standard and Premium disk , Disk Performance , attaching and preparing disks
# Default Azure disks 
 #    OS Disk can be sized upto 4 TB and hosts VMs OS : its hould host app or data
 # To host app or data use data disk
 # Temp disk : SSD located on the same Azure host as the VM :  highly performance 
 # used for  operations suchh as temp data processing. The size of this disk depend on the VM size

 # Azure Data Disk
    # Standard disk :  HDD  and cost effective storage
    # Premium disk : SSD based high performance , low latency disk. Perfect for Production workload

    # Create and Attach Disk

        # Step 1:  Create Initial Configuration
         $diskConfig=New-AzureRmDiskConfig -Location $location -CreateOption Empty -DiskSizeGB 128

         # Step 2 : Create Disk
         $dataDisk = New-AzureRmDisk -ResourceGroupName $resourceGpName -Disk $diskConfig -DiskName "appdisk"

         # Step 3:  Get the Virtual Machine
         $vm =Get-AzureRmVM -ResourceGroupName $resourceGpName -Name $vmName

         # Step 4 :   Add a data disk to the Virtual Machine config
         $vm =Add-AzureRmVMDataDisk -Vm $vm -CreateOption Attach -ManagedDiskId $dataDisk.Id -Lun 1

         # Step 5:   Update the Virtual MAchine : 
         # LUN specifies the slot in which the data drive appears when mounted for usage by the virtual machine.
          #It has valid LUN values are 0 through 15. On the VM,

         Update-AzureRmVm -ResourceGroupName $resourceGpName -VM $vm
#==================================================================================

##### Add Custom Script Extension 
# Custom Script Extension download and executes scripts on Azure VMs . 
# This Extension is useful for deployment configuration,software  installation or any other config mgmt tasks

 # Automate IIS install
 Set-AzureRmVMExtension -ResourceGroupName $resourceGpName `
    -ExtensionName "IIS" `
    -VMName $vmName `
    -Location $location `
    -Publisher Microsoft.Compute `
    -ExtensionType CustomScriptExtension `
    -TypeHandlerVersion 1.8 `
    -SettingString '{"commandToExecute":"powershell Add-WindowsFeature Web-Server; powershell Add-Content -Path \"C:\\inetpub\\wwwroot\\Default.htm\" -Value $($env:computername)"}'


# ==============================================================================
### Create VM images
# Custom Images they are like market place images but you create them yourself.
# Custom Images can be used to bootstrap config such as preloading config and other os config.
# Steps  to create vm images
# 1. SysPrep and generalize VM
# 2. Create a custom image
# 3. Create a VM from a Custom images
# 4. List all the images in your subscription
# 5. Delete an image

## Do SysPrep : https://docs.microsoft.com/en-us/azure/virtual-machines/windows/tutorial-custom-images
#  SysPrep : Removes all personal account information , among other things and prepares the machine
# to be used as image

## To Create an Image the VM needs to be deallocated and marked as Generalized in Azure
 
 Stop-AzureRmVM -ResourceGroupName $resourceGpName -Name $vmName  -Force

 # Set the status as Generalized

 Set-AzureRmVM -ResourceGroupName $resourceGpName -Name $vmName -Generalized

 ###  Create The Image

    # Get the Image
    $vm= Get-AzureRmVM -ResourceGroupName $resourceGpName -Name $vmName
    # Create the Image
    $image=New-AzureRmImageConfig -Location $location -SourceVirtualMachineId $vm.Id

    # Create the Image
    New-AzureRmImage -Image $image -ImageName "SwpnlgkwdWiproImage" -ResourceGroupName $resourceGpName

    # How to Create a VM from existing Image

    $vmNewVM=Read-Host "Enter the VM Name "

    $cred = Get-Credential -Message "Enter a username and password for the virtual machine."
    New-AzureRmVm `
    -ResourceGroupName $resourceGpName `
    -Name $vmNewVM `
    -Location $location `
    -VirtualNetworkName $vnetName `
    -SubnetName $frontEndSubnet `
    -SecurityGroupName $nsgGroup `
    -PublicIpAddressName $publicIP `
    -Credential $cred

