﻿Login-AzureRmAccount
Set-AzureRmContext -Subscription "Context Hosting"
$cred = Get-Credential
$NumberOfVM = 2;
$ResourceGroupName = "MSMUMGroup"
$Location = "South India"
$VNetName = "Mum-533-Vnet"
$SubnetName = "default"

$i = 1;

Do 
{ 
    $i; 
    $vmName="533vm"+$i
    $nsgName= "533VMNsg" + $i
    $pipName = "533VMPIP" + $i
    $domainLabel = "synmumvm"+$i
    New-AzureRmVm `
    -DomainNameLabel $domainLabel `
    -ResourceGroupName $ResourceGroupName `
    -Name $vmName `
    -ImageName "myImage" `
    -Location $Location `
    -VirtualNetworkName $VNetName `
    -SubnetName $SubnetName `
    -SecurityGroupName $nsgName `
    -PublicIpAddressName $pipName `
    -Credential $cred `
    -OpenPorts 3389
    
    $i +=1
} 
Until ($i -gt $NumberOfVM) 

