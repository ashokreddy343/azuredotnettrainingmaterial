﻿Get-Module -ListAvailable -Name AzureRm.Resources | Select Version

# Old : For powershell version <3.0.0
New-AzureRmResourceGroup -Tags @{ Name = "testtag"; Value = "testval" } -Name DeliveryGroup -Location 'SouthEast Asia'

# New : For powershell version >3.0.0
New-AzureRmResourceGroup -Tag @{ testtag = "testval" } -Name DeliveryGroup -Location 'SouthEast Asia'

#applies two tags to your storage account
Set-AzureRmResource -Tag @{ Dept="IT"; Environment="Test" } -ResourceName mystoragename -ResourceGroupName TestRG1 -ResourceType Microsoft.Storage/storageAccounts

