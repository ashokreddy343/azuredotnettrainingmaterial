﻿Login-AzureRmAccount

Get-AzureRmSubscription

Set-AzureRmContext -SubscriptionName 'Developer Program Benefit'

#List all available resource providers
Get-AzureRmResourceProvider -ListAvailable

#List all resources under Microsoft.Web provider
(Get-AzureRmResourceProvider -ProviderNamespace Microsoft.Web).ResourceTypes