﻿
Login-AzureRmAccount

Set-AzureRmContext -SubscriptionName "Developer Program Benefit"

New-AzureRmResourceGroupDeployment -Name "VNETCreation" `
                                -TemplateFile "C:\Users\sonusathyadas\Desktop\azuredeploy.json " `
                                -TemplateParameterFile "C:\Users\sonusathyadas\Desktop\azuredeploy.parameters.json" `
                                -ResourceGroupName "MSResGrp"
