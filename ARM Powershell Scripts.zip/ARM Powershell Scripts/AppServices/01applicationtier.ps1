﻿
#Configure Availability Set using PowerShell
 Login-AzureRmAccount
 Get-AzureRmSubscription
 Select-AzureRmSubscription -SubscriptionId "37d3d0a6-99f9-492b-87a5-5b88e80bd69c"
New-AzureRmResourceGroup -Name wiproResourceAvailability1 -Location EastUS
New-AzureRmAvailabilitySet `
   -Location "EastUS" `
   -Name "WebSevers" `
   -ResourceGroupName "wiproResourceAvailability1" `
   -Sku aligned `
   -PlatformFaultDomainCount 2 `
   -PlatformUpdateDomainCount 2

$cred = Get-Credential
for ($i=1; $i -le 2; $i++)
{
    New-AzureRmVm `
        -ResourceGroupName "wiproResourceAvailability1" `
        -Name "myVM$i" `
        -Location "East US" `
        -VirtualNetworkName "myVnet" `
        -SubnetName "webServerSubnet" `
        -SecurityGroupName "webNetworkSecurityGroup" `
        -PublicIpAddressName "myPublicIpAddress$i" `
        -AvailabilitySetName "WebSevers" `
        -Credential $cred
}

# Create Database Server

New-AzureRmAvailabilitySet `
   -Location "EastUS" `
   -Name "DatabaseServer" `
   -ResourceGroupName "wiproResourceAvailability1" `
   -Sku aligned `
   -PlatformFaultDomainCount 2 `
   -PlatformUpdateDomainCount 2


for ($i=1; $i -le 2; $i++)
{
    New-AzureRmVm `
        -ResourceGroupName "wiproResourceAvailability1" `
        -Name "dbVM$i" `
        -Location "East US" `
        -VirtualNetworkName "myVnet2" `
        -SubnetName "DbSubnet" `
        -SecurityGroupName "dbNetworkSecurityGroup" `
        -PublicIpAddressName "dbPublicIpAddress$i" `
        -AvailabilitySetName "DatabaseServer" `
        -Credential $cred
}




# Create Application Server

New-AzureRmAvailabilitySet `
   -Location "EastUS" `
   -Name "ApplicationServer" `
   -ResourceGroupName "wiproResourceAvailability1" `
   -Sku aligned `
   -PlatformFaultDomainCount 2 `
   -PlatformUpdateDomainCount 2



for ($i=1; $i -le 2; $i++)
{
    New-AzureRmVm `
        -ResourceGroupName "wiproResourceAvailability1" `
        -Name "appVM$i" `
        -Location "East US" `
        -VirtualNetworkName "myVnet1" `
        -SubnetName "AppSubnet" `
        -SecurityGroupName "appNetworkSecurityGroup" `
        -PublicIpAddressName "appPublicIpAddress$i" `
        -AvailabilitySetName "ApplicationServer" `
        -Credential $cred
}